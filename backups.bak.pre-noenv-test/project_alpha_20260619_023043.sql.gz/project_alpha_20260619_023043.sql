-- MySQL dump 10.13  Distrib 8.4.9, for Linux (x86_64)
--
-- Host: localhost    Database: project_alpha
-- ------------------------------------------------------
-- Server version	8.4.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_keys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_prefix` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scopes` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowed_ips` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_key_hash` (`key_hash`),
  KEY `idx_api_keys_prefix` (`key_prefix`),
  KEY `idx_api_keys_revoked` (`revoked_at`),
  KEY `idx_api_keys_org` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_usage`
--

DROP TABLE IF EXISTS `api_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_usage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `api_key_id` int NOT NULL,
  `used_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_api_usage_key_time` (`api_key_id`,`used_at`),
  CONSTRAINT `fk_api_usage_key` FOREIGN KEY (`api_key_id`) REFERENCES `api_keys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_usage`
--

LOCK TABLES `api_usage` WRITE;
/*!40000 ALTER TABLE `api_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_config`
--

DROP TABLE IF EXISTS `app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL DEFAULT '0',
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_config` (`organization_id`,`config_key`),
  KEY `idx_config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_config`
--

LOCK TABLES `app_config` WRITE;
/*!40000 ALTER TABLE `app_config` DISABLE KEYS */;
INSERT INTO `app_config` VALUES (1,0,'brand_name','Project Alpha','2026-06-16 14:35:40'),(2,0,'timezone','UTC','2026-06-16 14:35:40'),(3,0,'primary_state','','2026-06-16 14:35:40');
/*!40000 ALTER TABLE `app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archived_clients`
--

DROP TABLE IF EXISTS `archived_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `archived_clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `address_line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'US',
  `created_at` timestamp NULL DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_archived_clients_client` (`client_id`),
  KEY `idx_archived_clients_org` (`organization_id`),
  KEY `idx_archived_clients_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archived_clients`
--

LOCK TABLES `archived_clients` WRITE;
/*!40000 ALTER TABLE `archived_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `archived_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archived_entities`
--

DROP TABLE IF EXISTS `archived_entities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `archived_entities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int NOT NULL,
  `payload` json NOT NULL,
  `archived_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_arch_entities_client` (`client_id`),
  KEY `idx_arch_entities_org` (`organization_id`),
  KEY `idx_arch_entities_type` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archived_entities`
--

LOCK TABLES `archived_entities` WRITE;
/*!40000 ALTER TABLE `archived_entities` DISABLE KEYS */;
/*!40000 ALTER TABLE `archived_entities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_schedule_logs`
--

DROP TABLE IF EXISTS `audit_schedule_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_schedule_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schedule_id` int NOT NULL,
  `status` enum('pending','running','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `result_summary` text COLLATE utf8mb4_unicode_ci,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_log_schedule` (`schedule_id`),
  KEY `idx_audit_log_status` (`status`),
  CONSTRAINT `fk_audit_log_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `audit_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_schedule_logs`
--

LOCK TABLES `audit_schedule_logs` WRITE;
/*!40000 ALTER TABLE `audit_schedule_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_schedule_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_schedules`
--

DROP TABLE IF EXISTS `audit_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `frequency` enum('weekly','monthly','quarterly','annually') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `date_range_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'current_year',
  `email_addresses` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `include_invoices` tinyint(1) NOT NULL DEFAULT '1',
  `include_unpaid_invoices` tinyint(1) NOT NULL DEFAULT '0',
  `include_contracts` tinyint(1) NOT NULL DEFAULT '0',
  `include_quotes` tinyint(1) NOT NULL DEFAULT '0',
  `generate_csv` tinyint(1) NOT NULL DEFAULT '1',
  `include_pdfs` tinyint(1) NOT NULL DEFAULT '0',
  `options` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `next_run_at` datetime DEFAULT NULL,
  `last_run_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_sched_org` (`organization_id`),
  KEY `idx_audit_sched_active` (`is_active`),
  KEY `idx_audit_sched_next` (`next_run_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_schedules`
--

LOCK TABLES `audit_schedules` WRITE;
/*!40000 ALTER TABLE `audit_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto_pay_log`
--

DROP TABLE IF EXISTS `auto_pay_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auto_pay_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` enum('succeeded','failed','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_auto_pay_client` (`client_id`),
  KEY `idx_auto_pay_invoice` (`invoice_id`),
  KEY `idx_auto_pay_status` (`status`),
  CONSTRAINT `fk_auto_pay_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_auto_pay_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto_pay_log`
--

LOCK TABLES `auto_pay_log` WRITE;
/*!40000 ALTER TABLE `auto_pay_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `auto_pay_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'US',
  `organization_id` int DEFAULT NULL,
  `config` json DEFAULT NULL,
  `stripe_customer_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_payment_method_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_pay_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `archive_payload` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `custom_fields` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_clients_name` (`name`),
  KEY `idx_clients_email` (`email`),
  KEY `idx_clients_org` (`organization_id`),
  KEY `idx_clients_stripe_customer` (`stripe_customer_id`),
  KEY `idx_clients_archived` (`archived`),
  KEY `idx_clients_deleted` (`deleted_at`),
  CONSTRAINT `fk_clients_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Test Client E2E','e2e@test.com',NULL,NULL,NULL,NULL,NULL,NULL,'US',2,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,'2026-06-17 02:43:20','2026-06-17 02:43:20');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_items`
--

DROP TABLE IF EXISTS `contract_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(10,2) NOT NULL DEFAULT '1.00',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contract_items_contract` (`contract_id`),
  KEY `idx_contract_items_sort` (`sort_order`),
  CONSTRAINT `fk_contract_items_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_items`
--

LOCK TABLES `contract_items` WRITE;
/*!40000 ALTER TABLE `contract_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_signatures`
--

DROP TABLE IF EXISTS `contract_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_signatures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int NOT NULL,
  `signatory_type` enum('client','admin','witness') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'client',
  `signature_data` text COLLATE utf8mb4_unicode_ci,
  `signed_at` timestamp NULL DEFAULT NULL,
  `signed_by_user_id` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cs_contract` (`contract_id`),
  KEY `idx_cs_type` (`signatory_type`),
  KEY `fk_cs_user` (`signed_by_user_id`),
  CONSTRAINT `fk_cs_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cs_user` FOREIGN KEY (`signed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_signatures`
--

LOCK TABLES `contract_signatures` WRITE;
/*!40000 ALTER TABLE `contract_signatures` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_signatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quote_id` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `doc_number` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','pending','active','paused','completed','cancelled','denied','void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `contract_type` enum('regular','long_term','on_demand') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  `discount_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) DEFAULT NULL,
  `tax_county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `deposit_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `billing_interval_count` int NOT NULL DEFAULT '1',
  `billing_interval_unit` enum('day','week','month','year') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `pricing_type` enum('per_invoice','fixed_total','on_demand') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_per_invoice` decimal(12,2) DEFAULT NULL,
  `total_invoiced` decimal(12,2) NOT NULL DEFAULT '0.00',
  `next_invoice_date` date DEFAULT NULL,
  `last_invoice_date` date DEFAULT NULL,
  `invoice_count` int DEFAULT NULL,
  `invoices_generated` int NOT NULL DEFAULT '0',
  `invoice_generation_type` enum('set_amount','itemized','general_writeup') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'set_amount',
  `signed_pdf_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signed_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `voided_at` timestamp NULL DEFAULT NULL,
  `scheduled_date` date DEFAULT NULL,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `memo` text COLLATE utf8mb4_unicode_ci,
  `fulfillment_date` date DEFAULT NULL,
  `weather_pending` tinyint(1) NOT NULL DEFAULT '0',
  `estimated_completion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_fields` json DEFAULT NULL,
  `auto_pay_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `payment_method_id` int DEFAULT NULL,
  `stripe_subscription_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_date_updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contracts_client` (`client_id`),
  KEY `idx_contracts_project` (`project_id`),
  KEY `idx_contracts_org` (`organization_id`),
  KEY `idx_contracts_status` (`status`),
  KEY `idx_contracts_type` (`contract_type`),
  KEY `idx_contracts_doc_number` (`doc_number`),
  KEY `idx_contracts_project_code` (`project_code`),
  KEY `idx_contracts_quote` (`quote_id`),
  KEY `idx_contracts_next_invoice` (`next_invoice_date`),
  KEY `idx_contracts_auto_pay` (`auto_pay_enabled`),
  KEY `idx_contracts_stripe_sub` (`stripe_subscription_id`),
  CONSTRAINT `fk_contracts_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_contracts_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_contracts_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_contracts_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron_job_runs`
--

DROP TABLE IF EXISTS `cron_job_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cron_job_runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` enum('running','completed','failed','success') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `result` text COLLATE utf8mb4_unicode_ci,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cron_job_name` (`job_name`),
  KEY `idx_cron_started` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_job_runs`
--

LOCK TABLES `cron_job_runs` WRITE;
/*!40000 ALTER TABLE `cron_job_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cron_job_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts`
--

DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_type` enum('percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_discounts_org` (`organization_id`),
  KEY `idx_discounts_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts`
--

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_custom_fields`
--

DROP TABLE IF EXISTS `document_custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_custom_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'quote',
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_data_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_type` enum('text','number','date','boolean','select','textarea') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `field_options` json DEFAULT NULL,
  `default_value` text COLLATE utf8mb4_unicode_ci,
  `min_value` decimal(12,2) DEFAULT NULL,
  `max_value` decimal(12,2) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_builtin` tinyint(1) NOT NULL DEFAULT '0',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_doc_cf_org` (`organization_id`),
  KEY `idx_doc_cf_type` (`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_custom_fields`
--

LOCK TABLES `document_custom_fields` WRITE;
/*!40000 ALTER TABLE `document_custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_settings`
--

DROP TABLE IF EXISTS `document_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL DEFAULT '0',
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` json DEFAULT NULL,
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_doc_settings` (`organization_id`,`document_type`,`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_settings`
--

LOCK TABLES `document_settings` WRITE;
/*!40000 ALTER TABLE `document_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_links`
--

DROP TABLE IF EXISTS `entity_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entity_type` enum('client','organization','project') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_type` enum('manual','auto_dropbox','auto_gdrive','auto_s3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `expiration_date` date DEFAULT NULL,
  `is_expired` tinyint(1) NOT NULL DEFAULT '0',
  `ignore_auto_generation` tinyint(1) NOT NULL DEFAULT '0',
  `last_verified` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_link_entity` (`entity_type`,`entity_id`),
  KEY `idx_link_type` (`link_type`),
  KEY `idx_link_expired` (`is_expired`),
  KEY `idx_link_expiration` (`expiration_date`),
  KEY `idx_link_ignore` (`ignore_auto_generation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_links`
--

LOCK TABLES `entity_links` WRITE;
/*!40000 ALTER TABLE `entity_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_records`
--

DROP TABLE IF EXISTS `financial_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `record_type` enum('income','expense','refund','adjustment') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'income',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `transaction_date` date DEFAULT NULL,
  `payment_method` enum('cash','check','card','bank_transfer','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_financial_org` (`organization_id`),
  KEY `idx_financial_client` (`client_id`),
  KEY `idx_financial_type` (`record_type`),
  KEY `idx_financial_date` (`transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_records`
--

LOCK TABLES `financial_records` WRITE;
/*!40000 ALTER TABLE `financial_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `financial_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_categories`
--

DROP TABLE IF EXISTS `form_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('file','folder') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'folder',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_form_cat_org` (`organization_id`),
  KEY `idx_form_cat_type` (`type`),
  KEY `fk_form_cat_created_by` (`created_by`),
  CONSTRAINT `fk_form_cat_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_form_cat_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_categories`
--

LOCK TABLES `form_categories` WRITE;
/*!40000 ALTER TABLE `form_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_documents`
--

DROP TABLE IF EXISTS `form_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint unsigned DEFAULT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','active','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `uploaded_by` int DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_form_doc_org` (`organization_id`),
  KEY `idx_form_doc_category` (`category_id`),
  KEY `idx_form_doc_client` (`client_id`),
  KEY `idx_form_doc_project` (`project_id`),
  KEY `fk_form_docs_uploaded_by` (`uploaded_by`),
  CONSTRAINT `fk_form_docs_category` FOREIGN KEY (`category_id`) REFERENCES `form_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_form_docs_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_form_docs_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_form_docs_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_form_docs_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_documents`
--

LOCK TABLES `form_documents` WRITE;
/*!40000 ALTER TABLE `form_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(10,2) NOT NULL DEFAULT '1.00',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_extra_charge` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_invoice_items_invoice` (`invoice_id`),
  KEY `idx_invoice_items_sort` (`sort_order`),
  CONSTRAINT `fk_invoice_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_notifications`
--

DROP TABLE IF EXISTS `invoice_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `notification_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'reminder',
  `sent_at` timestamp NULL DEFAULT NULL,
  `email_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inv_notif_invoice` (`invoice_id`),
  KEY `idx_inv_notif_type` (`notification_type`),
  CONSTRAINT `fk_inv_notif_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_notifications`
--

LOCK TABLES `invoice_notifications` WRITE;
/*!40000 ALTER TABLE `invoice_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int DEFAULT NULL,
  `quote_id` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `doc_number` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','sent','unpaid','partial','paid','overdue','cancelled','void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `invoice_type` enum('regular','long_term','on_demand') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  `is_deposit_invoice` tinyint(1) NOT NULL DEFAULT '0',
  `parent_contract_type` enum('contract','long_term_contract','on_demand_contract') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax_county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `balance_due` decimal(12,2) NOT NULL DEFAULT '0.00',
  `due_date` date DEFAULT NULL,
  `fulfillment_date` date DEFAULT NULL,
  `weather_pending` tinyint(1) NOT NULL DEFAULT '0',
  `estimated_completion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `custom_fields` json DEFAULT NULL,
  `stripe_session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_auto_pay_attempt` timestamp NULL DEFAULT NULL,
  `document_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_date_updated_at` timestamp NULL DEFAULT NULL,
  `generated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_invoices_client` (`client_id`),
  KEY `idx_invoices_contract` (`contract_id`),
  KEY `idx_invoices_quote` (`quote_id`),
  KEY `idx_invoices_project` (`project_id`),
  KEY `idx_invoices_org` (`organization_id`),
  KEY `idx_invoices_status` (`status`),
  KEY `idx_invoices_type` (`invoice_type`),
  KEY `idx_invoices_doc_number` (`doc_number`),
  KEY `idx_invoices_project_code` (`project_code`),
  KEY `idx_invoices_due_date` (`due_date`),
  KEY `idx_invoices_auto_pay_attempt` (`last_auto_pay_attempt`),
  CONSTRAINT `fk_invoices_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invoices_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_library`
--

DROP TABLE IF EXISTS `item_library`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_library` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_item_lib_org` (`organization_id`),
  KEY `idx_item_lib_name` (`name`),
  KEY `idx_item_lib_sku` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_library`
--

LOCK TABLES `item_library` WRITE;
/*!40000 ALTER TABLE `item_library` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_library` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_resolver_config`
--

DROP TABLE IF EXISTS `link_resolver_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `link_resolver_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `credentials` json DEFAULT NULL,
  `default_expiration_days` int DEFAULT NULL,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_link_resolver` (`provider`,`config_key`),
  KEY `idx_link_resolver_provider` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_resolver_config`
--

LOCK TABLES `link_resolver_config` WRITE;
/*!40000 ALTER TABLE `link_resolver_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `link_resolver_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_2fa_attempts`
--

DROP TABLE IF EXISTS `login_2fa_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_2fa_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `success` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_2fa_attempts_user` (`user_id`),
  KEY `idx_2fa_attempts_ip` (`ip`),
  KEY `idx_2fa_attempts_time` (`attempted_at`),
  CONSTRAINT `fk_2fa_attempts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_2fa_attempts`
--

LOCK TABLES `login_2fa_attempts` WRITE;
/*!40000 ALTER TABLE `login_2fa_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_2fa_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_attempts_ip` (`ip`),
  KEY `idx_attempts_email` (`email`),
  KEY `idx_attempts_time` (`attempted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (1,'192.168.50.80','admin','2026-06-16 16:15:08'),(2,'192.168.50.80','admin','2026-06-16 16:15:13'),(3,'192.168.50.80','bkoltz','2026-06-16 16:15:22'),(4,'192.168.50.80','admin','2026-06-16 21:13:02');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`),
  KEY `idx_migrations_filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'001_auth_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(2,'002_organizations_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(3,'003_projects_clients_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(4,'004_documents_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(5,'005_financial_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(6,'006_audit_system_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(7,'007_migrate_and_drop_old_tables.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(8,'007_public_links_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(9,'008_documents_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(10,'008_seed_data.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(11,'009_auth_users_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(12,'010_financial_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(13,'011_projects_clients_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(14,'012_audit_system_module.sql','2026-06-16 19:25:07','applied_prior_to_tracking'),(15,'015_final_schema_sync.sql','2026-06-17 02:31:43','schema_sync_audit_schedules_cols');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `organization_id` int DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`),
  KEY `idx_notifications_read` (`is_read`),
  KEY `idx_notifications_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `tax_exempt_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_exempt_uploaded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_organizations_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (1,'Default Organization',NULL,NULL,NULL,'2026-06-16 14:35:40','2026-06-16 14:35:40'),(2,'Test Org E2E',NULL,NULL,NULL,'2026-06-17 02:42:24','2026-06-17 02:42:24');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(1) NOT NULL DEFAULT '0',
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_resets_user` (`user_id`),
  KEY `idx_resets_token` (`token`),
  CONSTRAINT `fk_resets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_intents`
--

DROP TABLE IF EXISTS `payment_intents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_intents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payment_intent_stripe` (`stripe_payment_intent_id`),
  KEY `idx_payment_intents_invoice` (`invoice_id`),
  CONSTRAINT `fk_payment_intents_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_intents`
--

LOCK TABLES `payment_intents` WRITE;
/*!40000 ALTER TABLE `payment_intents` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_intents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('cash','check','card','bank_transfer','stripe','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `config` json DEFAULT NULL,
  `last_four` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_month` int DEFAULT NULL,
  `exp_year` int DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `stripe_payment_method_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pm_user` (`user_id`),
  KEY `idx_pm_org` (`organization_id`),
  KEY `idx_pm_provider` (`provider`),
  CONSTRAINT `fk_pm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `invoice_id` int DEFAULT NULL,
  `contract_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `surcharge_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `payment_method` enum('cash','check','card','bank_transfer','stripe','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `payment_date` date NOT NULL,
  `reference_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `stripe_session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_pay_attempt` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('succeeded','failed','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'succeeded',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_payments_client` (`client_id`),
  KEY `idx_payments_invoice` (`invoice_id`),
  KEY `idx_payments_contract` (`contract_id`),
  KEY `idx_payments_date` (`payment_date`),
  KEY `idx_payments_stripe_session` (`stripe_session_id`),
  KEY `idx_payments_stripe_pi` (`stripe_payment_intent_id`),
  CONSTRAINT `fk_payments_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payments_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payments_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_counters`
--

DROP TABLE IF EXISTS `project_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_counters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `counter_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `counter_value` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_counter` (`organization_id`,`project_id`,`counter_type`),
  KEY `idx_counters_org` (`organization_id`),
  KEY `idx_counters_project` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_counters`
--

LOCK TABLES `project_counters` WRITE;
/*!40000 ALTER TABLE `project_counters` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_counters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_documents`
--

DROP TABLE IF EXISTS `project_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `document_type` enum('quote','contract','invoice','recurring_invoice','receipt','form','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `document_id` int NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_project_docs_project` (`project_id`),
  KEY `idx_project_docs_type` (`document_type`,`document_id`),
  CONSTRAINT `fk_project_docs_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_documents`
--

LOCK TABLES `project_documents` WRITE;
/*!40000 ALTER TABLE `project_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_meta`
--

DROP TABLE IF EXISTS `project_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_meta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `meta_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_project_meta_key` (`project_id`,`meta_key`),
  UNIQUE KEY `uq_project_meta_code` (`project_code`),
  KEY `idx_project_meta_client` (`client_id`),
  CONSTRAINT `fk_project_meta_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_project_meta_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_meta`
--

LOCK TABLES `project_meta` WRITE;
/*!40000 ALTER TABLE `project_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `parent_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('not_started','active','overdue','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_started',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `estimated_start` date DEFAULT NULL,
  `estimated_end` date DEFAULT NULL,
  `budget` decimal(12,2) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_projects_client` (`client_id`),
  KEY `idx_projects_org` (`organization_id`),
  KEY `idx_projects_status` (`status`),
  KEY `idx_projects_parent` (`parent_id`),
  CONSTRAINT `fk_projects_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_projects_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_projects_parent` FOREIGN KEY (`parent_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_links`
--

DROP TABLE IF EXISTS `public_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_id` int NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `expire_when_paid` tinyint(1) NOT NULL DEFAULT '0',
  `revoked` tinyint(1) NOT NULL DEFAULT '0',
  `redirect` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_count` int NOT NULL DEFAULT '0',
  `last_accessed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_public_links_token` (`token`),
  KEY `idx_public_links_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_links`
--

LOCK TABLES `public_links` WRITE;
/*!40000 ALTER TABLE `public_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `public_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_items`
--

DROP TABLE IF EXISTS `quote_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quote_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quote_id` int NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(10,2) NOT NULL DEFAULT '1.00',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_quote_items_quote` (`quote_id`),
  KEY `idx_quote_items_sort` (`sort_order`),
  CONSTRAINT `fk_quote_items_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_items`
--

LOCK TABLES `quote_items` WRITE;
/*!40000 ALTER TABLE `quote_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `doc_number` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','pending','approved','denied','rejected','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `quote_type` enum('regular','long_term','on_demand') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  `discount_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) DEFAULT NULL,
  `tax_county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `deposit_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `billing_interval_count` int NOT NULL DEFAULT '1',
  `billing_interval_unit` enum('day','week','month','year') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `pricing_type` enum('per_invoice','fixed_total','on_demand') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_per_invoice` decimal(12,2) DEFAULT NULL,
  `invoice_count` int DEFAULT NULL,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `fulfillment_date` date DEFAULT NULL,
  `weather_pending` tinyint(1) NOT NULL DEFAULT '0',
  `estimated_completion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_fields` json DEFAULT NULL,
  `document_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_date_updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_quotes_client` (`client_id`),
  KEY `idx_quotes_project` (`project_id`),
  KEY `idx_quotes_org` (`organization_id`),
  KEY `idx_quotes_status` (`status`),
  KEY `idx_quotes_type` (`quote_type`),
  KEY `idx_quotes_doc_number` (`doc_number`),
  KEY `idx_quotes_project_code` (`project_code`),
  CONSTRAINT `fk_quotes_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_quotes_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_quotes_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rate_limits`
--

DROP TABLE IF EXISTS `rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rate_limits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_identifier_created` (`identifier`,`created_at`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limits`
--

LOCK TABLES `rate_limits` WRITE;
/*!40000 ALTER TABLE `rate_limits` DISABLE KEYS */;
INSERT INTO `rate_limits` VALUES (83,'203.0.113.229:phpunit_13ee090b','203.0.113.229','2026-06-17 19:15:29'),(84,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(85,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(86,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(87,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(88,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(89,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(90,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(91,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(92,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29'),(93,'203.0.113.122:phpunit_fa939c79','203.0.113.122','2026-06-17 19:15:29');
/*!40000 ALTER TABLE `rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt_stores`
--

DROP TABLE IF EXISTS `receipt_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipt_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_receipt_store_org_name` (`organization_id`,`name`),
  KEY `idx_store_org` (`organization_id`),
  CONSTRAINT `fk_receipt_stores_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt_stores`
--

LOCK TABLES `receipt_stores` WRITE;
/*!40000 ALTER TABLE `receipt_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `store_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `receipt_date` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint unsigned DEFAULT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_receipt_org` (`organization_id`),
  KEY `idx_receipt_store` (`store_id`),
  KEY `idx_receipt_client` (`client_id`),
  KEY `idx_receipt_project` (`project_id`),
  KEY `idx_receipt_date` (`receipt_date`),
  KEY `fk_receipts_uploaded_by` (`uploaded_by`),
  CONSTRAINT `fk_receipts_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_receipts_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_receipts_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_receipts_store` FOREIGN KEY (`store_id`) REFERENCES `receipt_stores` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_receipts_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_audit`
--

DROP TABLE IF EXISTS `system_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_audit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `details` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_org` (`organization_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  KEY `idx_audit_created` (`created_at`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_audit`
--

LOCK TABLES `system_audit` WRITE;
/*!40000 ALTER TABLE `system_audit` DISABLE KEYS */;
INSERT INTO `system_audit` VALUES (1,NULL,NULL,'auth.login_failed','user',1,'{\"ip\": \"192.168.50.80\", \"input\": \"admin\"}','192.168.50.80','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','2026-06-16 16:15:08'),(2,NULL,NULL,'auth.login_failed','user',1,'{\"ip\": \"192.168.50.80\", \"input\": \"admin\"}','192.168.50.80','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','2026-06-16 16:15:13'),(3,NULL,NULL,'auth.login_failed','user',NULL,'{\"ip\": \"192.168.50.80\", \"input\": \"bkoltz\"}','192.168.50.80','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','2026-06-16 16:15:22'),(4,NULL,NULL,'auth.login_failed','user',1,'{\"ip\": \"192.168.50.80\", \"input\": \"admin\"}','192.168.50.80','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0','2026-06-16 21:13:02'),(5,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 02:39:06'),(6,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 02:39:06'),(7,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 02:41:06'),(8,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 02:41:31'),(9,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 02:42:24'),(10,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:43:19'),(11,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:14'),(12,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:14'),(13,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:14'),(14,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:14'),(15,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:50'),(16,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:50'),(17,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:50'),(18,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:44:50'),(19,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:45:37'),(20,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:45:37'),(21,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:51:24'),(22,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 04:51:24'),(23,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 04:51:24'),(24,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 04:52:03'),(25,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 04:52:03'),(26,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 04:52:03'),(27,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 04:52:03'),(28,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','192.168.50.80','curl/8.18.0','2026-06-17 14:42:20'),(29,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','192.168.50.80','curl/8.18.0','2026-06-17 14:43:37'),(30,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','192.168.50.80','curl/8.18.0','2026-06-17 14:53:02'),(31,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','192.168.50.80','curl/8.18.0','2026-06-17 14:53:33'),(32,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 500}','172.18.0.1','curl/8.18.0','2026-06-17 15:14:31'),(33,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 500}','172.18.0.1','curl/8.18.0','2026-06-17 15:14:31'),(34,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 500}','172.18.0.1','curl/8.18.0','2026-06-17 15:14:38'),(35,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 500}','172.18.0.1','curl/8.18.0','2026-06-17 15:15:15'),(36,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 500}','172.18.0.1','curl/8.18.0','2026-06-17 15:15:15'),(37,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 500}','172.18.0.1','curl/8.18.0','2026-06-17 15:15:26'),(38,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 15:15:55'),(39,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 200}','172.18.0.1','curl/8.18.0','2026-06-17 15:16:09'),(40,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 15:16:09'),(41,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','192.168.50.80','curl/8.18.0','2026-06-17 15:16:10'),(42,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 15:24:37'),(43,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 15:24:37'),(44,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 18:47:50'),(45,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 18:47:52'),(46,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 18:50:34'),(47,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook-legacy\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 18:50:34'),(48,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 18:59:11'),(49,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 19:06:43'),(50,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 19:09:00'),(51,NULL,NULL,'payment.stripe_webhook','payment',NULL,'{\"via\": \"middleware\", \"page\": \"stripe-webhook\", \"method\": \"POST\", \"http_status\": 400}','172.18.0.1','curl/8.18.0','2026-06-17 19:09:40');
/*!40000 ALTER TABLE `system_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_rates`
--

DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_rates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tax_org` (`organization_id`),
  KEY `idx_tax_county` (`county`),
  KEY `idx_tax_state` (`state`),
  KEY `idx_tax_zip` (`zip_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_rates`
--

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trusted_devices`
--

DROP TABLE IF EXISTS `trusted_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trusted_devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_verified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_trusted_devices_user` (`user_id`),
  KEY `idx_trusted_devices_token` (`device_token`),
  KEY `idx_trusted_devices_expires` (`expires_at`),
  CONSTRAINT `fk_trusted_devices_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trusted_devices`
--

LOCK TABLES `trusted_devices` WRITE;
/*!40000 ALTER TABLE `trusted_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `trusted_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trusted_ips`
--

DROP TABLE IF EXISTS `trusted_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trusted_ips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_trusted_ips_address` (`ip_address`),
  KEY `fk_trusted_ips_created_by` (`created_by`),
  CONSTRAINT `fk_trusted_ips_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trusted_ips`
--

LOCK TABLES `trusted_ips` WRITE;
/*!40000 ALTER TABLE `trusted_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `trusted_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_2fa`
--

DROP TABLE IF EXISTS `user_2fa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_2fa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `backup_codes` text COLLATE utf8mb4_unicode_ci,
  `enabled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_user_2fa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_2fa`
--

LOCK TABLES `user_2fa` WRITE;
/*!40000 ALTER TABLE `user_2fa` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_2fa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_organizations`
--

DROP TABLE IF EXISTS `user_organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_organizations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `role` enum('owner','admin','member') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_org` (`user_id`,`organization_id`),
  KEY `idx_uo_org` (`organization_id`),
  CONSTRAINT `fk_uo_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uo_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_organizations`
--

LOCK TABLES `user_organizations` WRITE;
/*!40000 ALTER TABLE `user_organizations` DISABLE KEYS */;
INSERT INTO `user_organizations` VALUES (1,1,1,'owner',1,'2026-06-16 14:35:40');
/*!40000 ALTER TABLE `user_organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `force_password_reset` tinyint(1) NOT NULL DEFAULT '0',
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin@project-alpha.local','{{ADMIN_PASSWORD_HASH}}','admin','admin',0,0,NULL,'2026-06-16 14:35:40','2026-06-16 14:35:40');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_event_log`
--

DROP TABLE IF EXISTS `webhook_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_event_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `event_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature_present` tinyint(1) NOT NULL DEFAULT '0',
  `signature_valid` tinyint(1) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload_size` int NOT NULL DEFAULT '0',
  `http_response_code` int DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `raw_payload` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_webhook_event_log_received_at` (`received_at`),
  KEY `idx_webhook_event_log_endpoint` (`endpoint`),
  KEY `idx_webhook_event_log_event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_event_log`
--

LOCK TABLES `webhook_event_log` WRITE;
/*!40000 ALTER TABLE `webhook_event_log` DISABLE KEYS */;
INSERT INTO `webhook_event_log` VALUES (1,'test','2026-06-17 15:15:06',NULL,NULL,0,NULL,'127.0.0.1',2,NULL,NULL,'{}','2026-06-17 15:15:06'),(2,'stripe-webhook','2026-06-17 15:15:55','test',NULL,0,NULL,'172.18.0.1',15,400,'Missing webhook signature','{\"type\":\"test\"}','2026-06-17 15:15:55'),(3,'stripe-webhook','2026-06-17 15:16:09','checkout.session.completed','evt_test_valid',1,1,'172.18.0.1',205,200,NULL,'{\"id\":\"evt_test_valid\",\"type\":\"checkout.session.completed\",\"data\":{\"object\":{\"id\":\"cs_test\",\"amount_total\":1000,\"currency\":\"usd\",\"metadata\":{\"invoice_id\":\"1\"},\"payment_status\":\"paid\",\"status\":\"complete\"}}}','2026-06-17 15:16:09'),(4,'stripe-webhook','2026-06-17 15:16:09','checkout.session.completed','evt_test_valid',1,NULL,'172.18.0.1',205,400,'Webhook signature verification failed','{\"id\":\"evt_test_valid\",\"type\":\"checkout.session.completed\",\"data\":{\"object\":{\"id\":\"cs_test\",\"amount_total\":1000,\"currency\":\"usd\",\"metadata\":{\"invoice_id\":\"1\"},\"payment_status\":\"paid\",\"status\":\"complete\"}}}','2026-06-17 15:16:09'),(5,'stripe-webhook','2026-06-17 15:16:10','invoice.payment_succeeded','evt_ext',0,NULL,'66.97.104.145',87,400,'Missing webhook signature','{\"id\":\"evt_ext\",\"type\":\"invoice.payment_succeeded\",\"data\":{\"object\":{\"id\":\"inv_test\"}}}','2026-06-17 15:16:10'),(6,'stripe-webhook','2026-06-17 15:24:37','test',NULL,0,NULL,'172.18.0.1',15,400,'Missing webhook signature','{\"type\":\"test\"}','2026-06-17 15:24:37'),(7,'stripe-webhook-legacy','2026-06-17 15:24:37','test',NULL,0,NULL,'172.18.0.1',15,400,'Missing webhook signature','{\"type\":\"test\"}','2026-06-17 15:24:37'),(8,'stripe-webhook','2026-06-17 18:47:50',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 18:47:50'),(9,'stripe-webhook-legacy','2026-06-17 18:47:52',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 18:47:52'),(10,'stripe-webhook','2026-06-17 18:50:34',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 18:50:34'),(11,'stripe-webhook-legacy','2026-06-17 18:50:34',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 18:50:34'),(12,'stripe-webhook','2026-06-17 18:59:11',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 18:59:11'),(13,'stripe-webhook','2026-06-17 19:06:43',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 19:06:43'),(14,'stripe-webhook','2026-06-17 19:09:00',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 19:09:00'),(15,'stripe-webhook','2026-06-17 19:09:40',NULL,NULL,0,0,'172.18.0.1',0,400,'No payload','','2026-06-17 19:09:40');
/*!40000 ALTER TABLE `webhook_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhooks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `events` json NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_webhooks_active` (`is_active`),
  KEY `idx_webhooks_org` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks`
--

LOCK TABLES `webhooks` WRITE;
/*!40000 ALTER TABLE `webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'project_alpha'
--

--
-- Dumping routines for database 'project_alpha'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19  7:30:43
