-- Project Alpha Database Backup
-- Generated: 2026-06-17 16:05:07 UTC
-- Database: project_alpha

SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

DROP TABLE IF EXISTS `api_keys`;
CREATE TABLE `api_keys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_prefix` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scopes` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowed_ips` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_key_hash` (`key_hash`),
  KEY `idx_api_keys_prefix` (`key_prefix`),
  KEY `idx_api_keys_revoked` (`revoked_at`),
  KEY `idx_api_keys_org` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `api_usage`;
CREATE TABLE `api_usage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `api_key_id` int NOT NULL,
  `used_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_api_usage_key_time` (`api_key_id`,`used_at`),
  CONSTRAINT `fk_api_usage_key` FOREIGN KEY (`api_key_id`) REFERENCES `api_keys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `app_config`;
CREATE TABLE `app_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL DEFAULT '0',
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_config` (`organization_id`,`config_key`),
  KEY `idx_config_key` (`config_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `app_config` VALUES
(1, 0, 'brand_name', 'Project Alpha', '2026-06-16 14:35:40'),
(2, 0, 'timezone', 'UTC', '2026-06-16 14:35:40'),
(3, 0, 'primary_state', '', '2026-06-16 14:35:40');

DROP TABLE IF EXISTS `archived_clients`;
CREATE TABLE `archived_clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `address_line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'US',
  `created_at` timestamp NULL DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_archived_clients_client` (`client_id`),
  KEY `idx_archived_clients_org` (`organization_id`),
  KEY `idx_archived_clients_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `archived_entities`;
CREATE TABLE `archived_entities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int NOT NULL,
  `payload` json NOT NULL,
  `archived_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_arch_entities_client` (`client_id`),
  KEY `idx_arch_entities_org` (`organization_id`),
  KEY `idx_arch_entities_type` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `audit_schedule_logs`;
CREATE TABLE `audit_schedule_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schedule_id` int NOT NULL,
  `status` enum('pending','running','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `result_summary` text COLLATE utf8mb4_unicode_ci,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_log_schedule` (`schedule_id`),
  KEY `idx_audit_log_status` (`status`),
  CONSTRAINT `fk_audit_log_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `audit_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `audit_schedules`;
CREATE TABLE `audit_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `frequency` enum('weekly','monthly','quarterly','annually') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `date_range_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'current_year',
  `email_addresses` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `include_invoices` tinyint(1) NOT NULL DEFAULT '1',
  `include_unpaid_invoices` tinyint(1) NOT NULL DEFAULT '0',
  `include_contracts` tinyint(1) NOT NULL DEFAULT '0',
  `include_quotes` tinyint(1) NOT NULL DEFAULT '0',
  `generate_csv` tinyint(1) NOT NULL DEFAULT '1',
  `include_pdfs` tinyint(1) NOT NULL DEFAULT '0',
  `options` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `next_run_at` datetime DEFAULT NULL,
  `last_run_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_sched_org` (`organization_id`),
  KEY `idx_audit_sched_active` (`is_active`),
  KEY `idx_audit_sched_next` (`next_run_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auto_pay_log`;
CREATE TABLE `auto_pay_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` enum('succeeded','failed','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_auto_pay_client` (`client_id`),
  KEY `idx_auto_pay_invoice` (`invoice_id`),
  KEY `idx_auto_pay_status` (`status`),
  CONSTRAINT `fk_auto_pay_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_auto_pay_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'US',
  `organization_id` int DEFAULT NULL,
  `config` json DEFAULT NULL,
  `stripe_customer_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_payment_method_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_pay_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `archive_payload` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `custom_fields` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_clients_name` (`name`),
  KEY `idx_clients_email` (`email`),
  KEY `idx_clients_org` (`organization_id`),
  KEY `idx_clients_stripe_customer` (`stripe_customer_id`),
  KEY `idx_clients_archived` (`archived`),
  KEY `idx_clients_deleted` (`deleted_at`),
  CONSTRAINT `fk_clients_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `clients` VALUES
(1, 'Test Client E2E', 'e2e@test.com', NULL, NULL, NULL, NULL, NULL, NULL, 'US', 2, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, '2026-06-17 02:43:20', '2026-06-17 02:43:20');

DROP TABLE IF EXISTS `contract_items`;
CREATE TABLE `contract_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(10,2) NOT NULL DEFAULT '1.00',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contract_items_contract` (`contract_id`),
  KEY `idx_contract_items_sort` (`sort_order`),
  CONSTRAINT `fk_contract_items_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `contract_signatures`;
CREATE TABLE `contract_signatures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int NOT NULL,
  `signatory_type` enum('client','admin','witness') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'client',
  `signature_data` text COLLATE utf8mb4_unicode_ci,
  `signed_at` timestamp NULL DEFAULT NULL,
  `signed_by_user_id` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cs_contract` (`contract_id`),
  KEY `idx_cs_type` (`signatory_type`),
  KEY `fk_cs_user` (`signed_by_user_id`),
  CONSTRAINT `fk_cs_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cs_user` FOREIGN KEY (`signed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `contracts`;
CREATE TABLE `contracts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quote_id` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `doc_number` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','pending','active','paused','completed','cancelled','denied','void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `contract_type` enum('regular','long_term','on_demand') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  `discount_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) DEFAULT NULL,
  `tax_county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `deposit_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `billing_interval_count` int NOT NULL DEFAULT '1',
  `billing_interval_unit` enum('day','week','month','year') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `pricing_type` enum('per_invoice','fixed_total','on_demand') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_per_invoice` decimal(12,2) DEFAULT NULL,
  `total_invoiced` decimal(12,2) NOT NULL DEFAULT '0.00',
  `next_invoice_date` date DEFAULT NULL,
  `last_invoice_date` date DEFAULT NULL,
  `invoice_count` int DEFAULT NULL,
  `invoices_generated` int NOT NULL DEFAULT '0',
  `invoice_generation_type` enum('set_amount','itemized','general_writeup') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'set_amount',
  `signed_pdf_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signed_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `voided_at` timestamp NULL DEFAULT NULL,
  `scheduled_date` date DEFAULT NULL,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `memo` text COLLATE utf8mb4_unicode_ci,
  `fulfillment_date` date DEFAULT NULL,
  `weather_pending` tinyint(1) NOT NULL DEFAULT '0',
  `estimated_completion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_fields` json DEFAULT NULL,
  `auto_pay_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `payment_method_id` int DEFAULT NULL,
  `stripe_subscription_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_date_updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contracts_client` (`client_id`),
  KEY `idx_contracts_project` (`project_id`),
  KEY `idx_contracts_org` (`organization_id`),
  KEY `idx_contracts_status` (`status`),
  KEY `idx_contracts_type` (`contract_type`),
  KEY `idx_contracts_doc_number` (`doc_number`),
  KEY `idx_contracts_project_code` (`project_code`),
  KEY `idx_contracts_quote` (`quote_id`),
  KEY `idx_contracts_next_invoice` (`next_invoice_date`),
  KEY `idx_contracts_auto_pay` (`auto_pay_enabled`),
  KEY `idx_contracts_stripe_sub` (`stripe_subscription_id`),
  CONSTRAINT `fk_contracts_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_contracts_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_contracts_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_contracts_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cron_job_runs`;
CREATE TABLE `cron_job_runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_run` datetime DEFAULT NULL,
  `status` enum('running','completed','failed','success') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `result` text COLLATE utf8mb4_unicode_ci,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cron_job_name` (`job_name`),
  KEY `idx_cron_started` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `discounts`;
CREATE TABLE `discounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_type` enum('percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_discounts_org` (`organization_id`),
  KEY `idx_discounts_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `document_custom_fields`;
CREATE TABLE `document_custom_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'quote',
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_data_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_type` enum('text','number','date','boolean','select','textarea') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `field_options` json DEFAULT NULL,
  `default_value` text COLLATE utf8mb4_unicode_ci,
  `min_value` decimal(12,2) DEFAULT NULL,
  `max_value` decimal(12,2) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_builtin` tinyint(1) NOT NULL DEFAULT '0',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_doc_cf_org` (`organization_id`),
  KEY `idx_doc_cf_type` (`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `document_settings`;
CREATE TABLE `document_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL DEFAULT '0',
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` json DEFAULT NULL,
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_doc_settings` (`organization_id`,`document_type`,`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `entity_links`;
CREATE TABLE `entity_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entity_type` enum('client','organization','project') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_type` enum('manual','auto_dropbox','auto_gdrive','auto_s3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `expiration_date` date DEFAULT NULL,
  `is_expired` tinyint(1) NOT NULL DEFAULT '0',
  `ignore_auto_generation` tinyint(1) NOT NULL DEFAULT '0',
  `last_verified` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_link_entity` (`entity_type`,`entity_id`),
  KEY `idx_link_type` (`link_type`),
  KEY `idx_link_expired` (`is_expired`),
  KEY `idx_link_expiration` (`expiration_date`),
  KEY `idx_link_ignore` (`ignore_auto_generation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `financial_records`;
CREATE TABLE `financial_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `record_type` enum('income','expense','refund','adjustment') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'income',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `transaction_date` date DEFAULT NULL,
  `payment_method` enum('cash','check','card','bank_transfer','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_financial_org` (`organization_id`),
  KEY `idx_financial_client` (`client_id`),
  KEY `idx_financial_type` (`record_type`),
  KEY `idx_financial_date` (`transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `form_categories`;
CREATE TABLE `form_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('file','folder') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'folder',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_form_cat_org` (`organization_id`),
  KEY `idx_form_cat_type` (`type`),
  KEY `fk_form_cat_created_by` (`created_by`),
  CONSTRAINT `fk_form_cat_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_form_cat_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `form_documents`;
CREATE TABLE `form_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint unsigned DEFAULT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','active','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `uploaded_by` int DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_form_doc_org` (`organization_id`),
  KEY `idx_form_doc_category` (`category_id`),
  KEY `idx_form_doc_client` (`client_id`),
  KEY `idx_form_doc_project` (`project_id`),
  KEY `fk_form_docs_uploaded_by` (`uploaded_by`),
  CONSTRAINT `fk_form_docs_category` FOREIGN KEY (`category_id`) REFERENCES `form_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_form_docs_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_form_docs_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_form_docs_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_form_docs_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(10,2) NOT NULL DEFAULT '1.00',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_extra_charge` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_invoice_items_invoice` (`invoice_id`),
  KEY `idx_invoice_items_sort` (`sort_order`),
  CONSTRAINT `fk_invoice_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `invoice_notifications`;
CREATE TABLE `invoice_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `notification_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'reminder',
  `sent_at` timestamp NULL DEFAULT NULL,
  `email_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inv_notif_invoice` (`invoice_id`),
  KEY `idx_inv_notif_type` (`notification_type`),
  CONSTRAINT `fk_inv_notif_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int DEFAULT NULL,
  `quote_id` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `doc_number` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','sent','unpaid','partial','paid','overdue','cancelled','void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `invoice_type` enum('regular','long_term','on_demand') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  `is_deposit_invoice` tinyint(1) NOT NULL DEFAULT '0',
  `parent_contract_type` enum('contract','long_term_contract','on_demand_contract') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tax_county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `balance_due` decimal(12,2) NOT NULL DEFAULT '0.00',
  `due_date` date DEFAULT NULL,
  `fulfillment_date` date DEFAULT NULL,
  `weather_pending` tinyint(1) NOT NULL DEFAULT '0',
  `estimated_completion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `custom_fields` json DEFAULT NULL,
  `stripe_session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_auto_pay_attempt` timestamp NULL DEFAULT NULL,
  `document_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_date_updated_at` timestamp NULL DEFAULT NULL,
  `generated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_invoices_client` (`client_id`),
  KEY `idx_invoices_contract` (`contract_id`),
  KEY `idx_invoices_quote` (`quote_id`),
  KEY `idx_invoices_project` (`project_id`),
  KEY `idx_invoices_org` (`organization_id`),
  KEY `idx_invoices_status` (`status`),
  KEY `idx_invoices_type` (`invoice_type`),
  KEY `idx_invoices_doc_number` (`doc_number`),
  KEY `idx_invoices_project_code` (`project_code`),
  KEY `idx_invoices_due_date` (`due_date`),
  KEY `idx_invoices_auto_pay_attempt` (`last_auto_pay_attempt`),
  CONSTRAINT `fk_invoices_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invoices_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `item_library`;
CREATE TABLE `item_library` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_item_lib_org` (`organization_id`),
  KEY `idx_item_lib_name` (`name`),
  KEY `idx_item_lib_sku` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `link_resolver_config`;
CREATE TABLE `link_resolver_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `credentials` json DEFAULT NULL,
  `default_expiration_days` int DEFAULT NULL,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_link_resolver` (`provider`,`config_key`),
  KEY `idx_link_resolver_provider` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `login_2fa_attempts`;
CREATE TABLE `login_2fa_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `success` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_2fa_attempts_user` (`user_id`),
  KEY `idx_2fa_attempts_ip` (`ip`),
  KEY `idx_2fa_attempts_time` (`attempted_at`),
  CONSTRAINT `fk_2fa_attempts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_attempts_ip` (`ip`),
  KEY `idx_attempts_email` (`email`),
  KEY `idx_attempts_time` (`attempted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `login_attempts` VALUES
(1, '192.168.50.80', 'admin', '2026-06-16 16:15:08'),
(2, '192.168.50.80', 'admin', '2026-06-16 16:15:13'),
(3, '192.168.50.80', 'bkoltz', '2026-06-16 16:15:22'),
(4, '192.168.50.80', 'admin', '2026-06-16 21:13:02');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`),
  KEY `idx_migrations_filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES
(1, '001_auth_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(2, '002_organizations_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(3, '003_projects_clients_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(4, '004_documents_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(5, '005_financial_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(6, '006_audit_system_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(7, '007_migrate_and_drop_old_tables.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(8, '007_public_links_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(9, '008_documents_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(10, '008_seed_data.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(11, '009_auth_users_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(12, '010_financial_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(13, '011_projects_clients_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(14, '012_audit_system_module.sql', '2026-06-16 19:25:07', 'applied_prior_to_tracking'),
(15, '015_final_schema_sync.sql', '2026-06-17 02:31:43', 'schema_sync_audit_schedules_cols');

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `organization_id` int DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`),
  KEY `idx_notifications_read` (`is_read`),
  KEY `idx_notifications_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `organizations`;
CREATE TABLE `organizations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `tax_exempt_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_exempt_uploaded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_organizations_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `organizations` VALUES
(1, 'Default Organization', NULL, NULL, NULL, '2026-06-16 14:35:40', '2026-06-16 14:35:40'),
(2, 'Test Org E2E', NULL, NULL, NULL, '2026-06-17 02:42:24', '2026-06-17 02:42:24');

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` tinyint(1) NOT NULL DEFAULT '0',
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_resets_user` (`user_id`),
  KEY `idx_resets_token` (`token`),
  CONSTRAINT `fk_resets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payment_intents`;
CREATE TABLE `payment_intents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payment_intent_stripe` (`stripe_payment_intent_id`),
  KEY `idx_payment_intents_invoice` (`invoice_id`),
  CONSTRAINT `fk_payment_intents_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payment_methods`;
CREATE TABLE `payment_methods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('cash','check','card','bank_transfer','stripe','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `config` json DEFAULT NULL,
  `last_four` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_month` int DEFAULT NULL,
  `exp_year` int DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `stripe_payment_method_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pm_user` (`user_id`),
  KEY `idx_pm_org` (`organization_id`),
  KEY `idx_pm_provider` (`provider`),
  CONSTRAINT `fk_pm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `invoice_id` int DEFAULT NULL,
  `contract_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `surcharge_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `payment_method` enum('cash','check','card','bank_transfer','stripe','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `payment_date` date NOT NULL,
  `reference_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `stripe_session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_pay_attempt` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('succeeded','failed','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'succeeded',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_payments_client` (`client_id`),
  KEY `idx_payments_invoice` (`invoice_id`),
  KEY `idx_payments_contract` (`contract_id`),
  KEY `idx_payments_date` (`payment_date`),
  KEY `idx_payments_stripe_session` (`stripe_session_id`),
  KEY `idx_payments_stripe_pi` (`stripe_payment_intent_id`),
  CONSTRAINT `fk_payments_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payments_contract` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payments_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `project_counters`;
CREATE TABLE `project_counters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `counter_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `counter_value` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_counter` (`organization_id`,`project_id`,`counter_type`),
  KEY `idx_counters_org` (`organization_id`),
  KEY `idx_counters_project` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `project_documents`;
CREATE TABLE `project_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `document_type` enum('quote','contract','invoice','recurring_invoice','receipt','form','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `document_id` int NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_project_docs_project` (`project_id`),
  KEY `idx_project_docs_type` (`document_type`,`document_id`),
  CONSTRAINT `fk_project_docs_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `project_meta`;
CREATE TABLE `project_meta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `meta_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_project_meta_key` (`project_id`,`meta_key`),
  UNIQUE KEY `uq_project_meta_code` (`project_code`),
  KEY `idx_project_meta_client` (`client_id`),
  CONSTRAINT `fk_project_meta_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_project_meta_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `parent_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('not_started','active','overdue','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_started',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `estimated_start` date DEFAULT NULL,
  `estimated_end` date DEFAULT NULL,
  `budget` decimal(12,2) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_projects_client` (`client_id`),
  KEY `idx_projects_org` (`organization_id`),
  KEY `idx_projects_status` (`status`),
  KEY `idx_projects_parent` (`parent_id`),
  CONSTRAINT `fk_projects_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_projects_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_projects_parent` FOREIGN KEY (`parent_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `public_links`;
CREATE TABLE `public_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document_id` int NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `expire_when_paid` tinyint(1) NOT NULL DEFAULT '0',
  `revoked` tinyint(1) NOT NULL DEFAULT '0',
  `redirect` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_count` int NOT NULL DEFAULT '0',
  `last_accessed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_public_links_token` (`token`),
  KEY `idx_public_links_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `quote_items`;
CREATE TABLE `quote_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quote_id` int NOT NULL,
  `item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` decimal(10,2) NOT NULL DEFAULT '1.00',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_quote_items_quote` (`quote_id`),
  KEY `idx_quote_items_sort` (`sort_order`),
  CONSTRAINT `fk_quote_items_quote` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `quotes`;
CREATE TABLE `quotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `doc_number` int DEFAULT NULL,
  `project_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','pending','approved','denied','rejected','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `quote_type` enum('regular','long_term','on_demand') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  `discount_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(12,2) DEFAULT NULL,
  `tax_county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deposit_type` enum('none','percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `deposit_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `billing_interval_count` int NOT NULL DEFAULT '1',
  `billing_interval_unit` enum('day','week','month','year') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `pricing_type` enum('per_invoice','fixed_total','on_demand') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_per_invoice` decimal(12,2) DEFAULT NULL,
  `invoice_count` int DEFAULT NULL,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `fulfillment_date` date DEFAULT NULL,
  `weather_pending` tinyint(1) NOT NULL DEFAULT '0',
  `estimated_completion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_fields` json DEFAULT NULL,
  `document_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_date_updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_quotes_client` (`client_id`),
  KEY `idx_quotes_project` (`project_id`),
  KEY `idx_quotes_org` (`organization_id`),
  KEY `idx_quotes_status` (`status`),
  KEY `idx_quotes_type` (`quote_type`),
  KEY `idx_quotes_doc_number` (`doc_number`),
  KEY `idx_quotes_project_code` (`project_code`),
  CONSTRAINT `fk_quotes_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_quotes_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_quotes_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `receipt_stores`;
CREATE TABLE `receipt_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_receipt_store_org_name` (`organization_id`,`name`),
  KEY `idx_store_org` (`organization_id`),
  CONSTRAINT `fk_receipt_stores_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `receipts`;
CREATE TABLE `receipts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `store_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `receipt_date` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint unsigned DEFAULT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_receipt_org` (`organization_id`),
  KEY `idx_receipt_store` (`store_id`),
  KEY `idx_receipt_client` (`client_id`),
  KEY `idx_receipt_project` (`project_id`),
  KEY `idx_receipt_date` (`receipt_date`),
  KEY `fk_receipts_uploaded_by` (`uploaded_by`),
  CONSTRAINT `fk_receipts_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_receipts_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_receipts_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_receipts_store` FOREIGN KEY (`store_id`) REFERENCES `receipt_stores` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_receipts_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `system_audit`;
CREATE TABLE `system_audit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `details` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_org` (`organization_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  KEY `idx_audit_created` (`created_at`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_audit` VALUES
(1, NULL, NULL, 'auth.login_failed', 'user', 1, '{"ip": "192.168.50.80", "input": "admin"}', '192.168.50.80', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-16 16:15:08'),
(2, NULL, NULL, 'auth.login_failed', 'user', 1, '{"ip": "192.168.50.80", "input": "admin"}', '192.168.50.80', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-16 16:15:13'),
(3, NULL, NULL, 'auth.login_failed', 'user', NULL, '{"ip": "192.168.50.80", "input": "bkoltz"}', '192.168.50.80', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-16 16:15:22'),
(4, NULL, NULL, 'auth.login_failed', 'user', 1, '{"ip": "192.168.50.80", "input": "admin"}', '192.168.50.80', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0', '2026-06-16 21:13:02'),
(5, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 02:39:06'),
(6, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 02:39:06'),
(7, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 02:41:06'),
(8, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 02:41:31'),
(9, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 02:42:24'),
(10, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:43:19'),
(11, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:14'),
(12, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:14'),
(13, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:14'),
(14, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:14'),
(15, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:50'),
(16, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:50'),
(17, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:50'),
(18, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:44:50'),
(19, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:45:37'),
(20, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:45:37'),
(21, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:51:24'),
(22, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:51:24'),
(23, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:51:24'),
(24, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:52:03'),
(25, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:52:03'),
(26, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:52:03'),
(27, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 04:52:03'),
(28, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '192.168.50.80', 'curl/8.18.0', '2026-06-17 14:42:20'),
(29, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '192.168.50.80', 'curl/8.18.0', '2026-06-17 14:43:37'),
(30, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '192.168.50.80', 'curl/8.18.0', '2026-06-17 14:53:02'),
(31, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '192.168.50.80', 'curl/8.18.0', '2026-06-17 14:53:33'),
(32, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 500}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:14:31'),
(33, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 500}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:14:31'),
(34, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 500}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:14:38'),
(35, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 500}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:15:15'),
(36, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 500}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:15:15'),
(37, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 500}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:15:26'),
(38, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:15:55'),
(39, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 200}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:16:09'),
(40, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:16:09'),
(41, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '192.168.50.80', 'curl/8.18.0', '2026-06-17 15:16:10'),
(42, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:24:37'),
(43, NULL, NULL, 'payment.stripe_webhook', 'payment', NULL, '{"via": "middleware", "page": "stripe-webhook-legacy", "method": "POST", "http_status": 400}', '172.18.0.1', 'curl/8.18.0', '2026-06-17 15:24:37');

DROP TABLE IF EXISTS `tax_rates`;
CREATE TABLE `tax_rates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tax_org` (`organization_id`),
  KEY `idx_tax_county` (`county`),
  KEY `idx_tax_state` (`state`),
  KEY `idx_tax_zip` (`zip_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `trusted_devices`;
CREATE TABLE `trusted_devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_verified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_trusted_devices_user` (`user_id`),
  KEY `idx_trusted_devices_token` (`device_token`),
  KEY `idx_trusted_devices_expires` (`expires_at`),
  CONSTRAINT `fk_trusted_devices_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `trusted_ips`;
CREATE TABLE `trusted_ips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_trusted_ips_address` (`ip_address`),
  KEY `fk_trusted_ips_created_by` (`created_by`),
  CONSTRAINT `fk_trusted_ips_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_2fa`;
CREATE TABLE `user_2fa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `backup_codes` text COLLATE utf8mb4_unicode_ci,
  `enabled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_user_2fa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_organizations`;
CREATE TABLE `user_organizations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `role` enum('owner','admin','member') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_org` (`user_id`,`organization_id`),
  KEY `idx_uo_org` (`organization_id`),
  CONSTRAINT `fk_uo_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uo_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_organizations` VALUES
(1, 1, 1, 'owner', 1, '2026-06-16 14:35:40');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `force_password_reset` tinyint(1) NOT NULL DEFAULT '0',
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES
(1, 'admin@project-alpha.local', '{{ADMIN_PASSWORD_HASH}}', 'admin', 'admin', 0, 0, NULL, '2026-06-16 14:35:40', '2026-06-16 14:35:40');

DROP TABLE IF EXISTS `webhook_event_log`;
CREATE TABLE `webhook_event_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `event_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature_present` tinyint(1) NOT NULL DEFAULT '0',
  `signature_valid` tinyint(1) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload_size` int NOT NULL DEFAULT '0',
  `http_response_code` int DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `raw_payload` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_webhook_event_log_received_at` (`received_at`),
  KEY `idx_webhook_event_log_endpoint` (`endpoint`),
  KEY `idx_webhook_event_log_event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `webhook_event_log` VALUES
(1, 'test', '2026-06-17 15:15:06', NULL, NULL, 0, NULL, '127.0.0.1', 2, NULL, NULL, '{}', '2026-06-17 15:15:06'),
(2, 'stripe-webhook', '2026-06-17 15:15:55', 'test', NULL, 0, NULL, '172.18.0.1', 15, 400, 'Missing webhook signature', '{"type":"test"}', '2026-06-17 15:15:55'),
(3, 'stripe-webhook', '2026-06-17 15:16:09', 'checkout.session.completed', 'evt_test_valid', 1, 1, '172.18.0.1', 205, 200, NULL, '{"id":"evt_test_valid","type":"checkout.session.completed","data":{"object":{"id":"cs_test","amount_total":1000,"currency":"usd","metadata":{"invoice_id":"1"},"payment_status":"paid","status":"complete"}}}', '2026-06-17 15:16:09'),
(4, 'stripe-webhook', '2026-06-17 15:16:09', 'checkout.session.completed', 'evt_test_valid', 1, NULL, '172.18.0.1', 205, 400, 'Webhook signature verification failed', '{"id":"evt_test_valid","type":"checkout.session.completed","data":{"object":{"id":"cs_test","amount_total":1000,"currency":"usd","metadata":{"invoice_id":"1"},"payment_status":"paid","status":"complete"}}}', '2026-06-17 15:16:09'),
(5, 'stripe-webhook', '2026-06-17 15:16:10', 'invoice.payment_succeeded', 'evt_ext', 0, NULL, '66.97.104.145', 87, 400, 'Missing webhook signature', '{"id":"evt_ext","type":"invoice.payment_succeeded","data":{"object":{"id":"inv_test"}}}', '2026-06-17 15:16:10'),
(6, 'stripe-webhook', '2026-06-17 15:24:37', 'test', NULL, 0, NULL, '172.18.0.1', 15, 400, 'Missing webhook signature', '{"type":"test"}', '2026-06-17 15:24:37'),
(7, 'stripe-webhook-legacy', '2026-06-17 15:24:37', 'test', NULL, 0, NULL, '172.18.0.1', 15, 400, 'Missing webhook signature', '{"type":"test"}', '2026-06-17 15:24:37');

DROP TABLE IF EXISTS `webhooks`;
CREATE TABLE `webhooks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `events` json NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_webhooks_active` (`is_active`),
  KEY `idx_webhooks_org` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
